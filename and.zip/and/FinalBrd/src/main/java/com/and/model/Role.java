package com.and.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



/********************************************************           
 * USER ROLE --POJO class for Role		                *   
 *                                                      *   
 * Author:  NIKHIL GUPTA	                            *   
 *                                                      *   
 * Purpose: To Store All User Related data 		        *   
 *                                                      *   
 * Usage:                                               *   
 *     works As class to store All the data of User Role*   
 ********************************************************/






 
@Entity
@Table(name = "nikhil_role")
public class Role 
{
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int id;

	@Column(name = "Role")
	private String role;

	@Column(name = "Description")
	private String description;




//Getters and Setters----------------------------------------------------------



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}







//Constructors---------------------------------------------------------------------------

	public Role() {

	}

	public Role(int id, String role, String description) {
		super();
		this.id = id;
		this.role = role;
		this.description = description;
	}



//To String -------------------------------------------------------------------------------
	@Override
	public String toString() {
		return  role ;
	}

}
