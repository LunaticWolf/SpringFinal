package com.and.service;

import java.util.logging.Logger;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.and.model.User;

public class EncodingPassword 
{

	//logger
	static Logger log = Logger.getLogger(EncodingPassword.class.getName());
	

	//Instantiate Encrypter
	BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	

	//Encrypting User Password
	public void encryptPass(User user)
	{
		String pass = passwordEncoder.encode(user.getPassword());
		user.setPassword(pass);
	}
}

