package com.nucleus.nsbt.brd4.spring.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nucleus.nsbt.brd4.spring.entity.Customer;


@Repository
public class CustomerDaoImpl  implements CustomerDao
{

	@Autowired
	SessionFactory sessionFactory;
	
	
	//Save Added Record
	@Override
	public void saveCustomer(Customer theCustomer) 
	{
		Session session = sessionFactory.getCurrentSession();
		session.save(theCustomer);
	}
	
	
	
	//Get Records
	@Override
	public List<Customer> getCustomers() 
	{
		Session session = sessionFactory.getCurrentSession();
		
		Query theQuery = session.createQuery("from Customer_18060163");
		@SuppressWarnings("unchecked")
		List<Customer> customers = theQuery.list();
		
		return customers;
	}

	
	//Get Record
	@Override
	public Customer getCustomer(int theId) 
	{
		Session session = sessionFactory.getCurrentSession();
		Customer theCustomer = (Customer) session.get(Customer.class, theId);
		
		return theCustomer;
		
	}

	
	//Update Record
		@Override
		public void updateCustomer(Customer theCustomer) 
		{
			Session session = sessionFactory.getCurrentSession();
			
			session.update(theCustomer);
		}
	
	//Delete Record
	@Override
	public void deleteCustomer(int theId) 
	{
		Session session = sessionFactory.getCurrentSession();
		Customer theCustomer = (Customer) session.get(Customer.class, theId);
		
		session.delete(theCustomer);
	}

	
	

	
}
