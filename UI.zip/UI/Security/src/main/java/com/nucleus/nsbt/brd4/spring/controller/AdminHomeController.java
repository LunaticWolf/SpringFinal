package com.nucleus.nsbt.brd4.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

//import com.nucleus.nsbt.brd4.spring.entity.User;
//import com.nucleus.nsbt.brd4.spring.service.UserService;



@Controller
public class AdminHomeController 
{
	
	
	@Autowired
	//private UserService userService;
	
	
	//Admin Home Screen 
	@GetMapping("/admin-Screen")
	public String showHome() 
	{		
		return "admin-screen";
	}
}	
/*	//Add User
	@GetMapping("/addUser")
	public String showAddUser(Model theModel) 
	{		
		User theUser = new User();
		theModel.addAttribute("THE_USER", theUser);
		
		return "add-new-user";
	}
	
	
	@PostMapping("/saveUser")
	public String saveUser(@ModelAttribute("THE_USER") User theUser)
	{
		userService.saveUser(theUser);
		
		return "redirect:/viewUsers";
	}
	
	@PostMapping("/viewUsers")
	public String showUsers(Model theModel)
	{
		List<User> theUsers = userService.getUsers();
		
		theModel.addAttribute("THE_USERS", theUsers);
		
		return "view-users";
	}
	
}
*/