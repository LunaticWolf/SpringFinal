package com.nucleus.nsbt.brd4.spring.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nucleus.nsbt.brd4.spring.dao.UserDao;
import com.nucleus.nsbt.brd4.spring.entity.User;

@Service
@Transactional
public class UserServiceImpl implements UserService
{

	@Autowired
	private UserDao userDao;
	
	
//View users	
	@Override
	public List<User> getUsers()
	{
		return userDao.getUsers();
	}
	
//Save Users	
	@Override
	public void saveUser(User theUser)
	{
		userDao.saveUser(theUser);
	}
	
	
}
