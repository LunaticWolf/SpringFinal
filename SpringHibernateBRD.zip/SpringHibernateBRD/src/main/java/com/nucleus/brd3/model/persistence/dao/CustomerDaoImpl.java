package com.nucleus.brd3.model.persistence.dao;

//import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

//import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
//import org.springframework.transaction.annotation.Transactional;

import com.nucleus.brd3.model.persistence.entity.Customer;


@Repository
public class CustomerDaoImpl implements CustomerDao
{

		@Autowired
	    SessionFactory sessionFactory;

		
		
		//Save Added Record
		public void addRecord(Customer customer) 
		{
			Session session = getSession();
			
			customer.setCreatedDate(getDate());
			
			session.save(customer);
		}

		
		
		
		//View Records
		@SuppressWarnings("unchecked")
		public List<Customer> getRecords() 
		{
			Session session = getSession();
			List<Customer> theCustomers = session.createQuery("from Customer").list();
			
			return theCustomers;
		}

		
		
		
		//View By Code
		public Customer getRecordByCode(String customerCode) 
		{
			Session session = getSession();
			
			Customer theCustomer = (Customer) session.get(Customer.class, customerCode);
			
			return theCustomer;
		}

		
		
		//View By Name
		public List<Customer> getRecordByName(String customerName) 
		{
			Session session = getSession();
			
			List<Customer> theCustomers = (List<Customer>) session.get(Customer.class, customerName);

			return theCustomers;
		}

		
		
		//Update Record-ID
		public Customer getRecordToUpdate(String customerCode) 
		{
			Session session = getSession();
			
			//Customer theCustomer = (Customer) session.get(Customer.class, customerCode);
			
			Customer theCustomer = getRecordByCode(customerCode);
			
			return theCustomer;
		}

		
		
		//Update Record
		public void updateRecord(Customer customer) 
		{
			Session session = getSession();
			
			customer.setModifiedDate(getDate());
			
			session.update(customer);
			
		}

		
		
		//DeleteRecord
		public void deleteRecord(String customerCode) 
		{
			Session session = getSession();
			
			//Customer theCustomer = (Customer) session.get(Customer.class, customerCode);
			
			Customer theCustomer = getRecordByCode(customerCode); 
			
			session.delete(theCustomer);
			
			
			
		}
		
		 
		
		
//Custom Methods		
		//Get Created/Modified Record Date
		public String getDate()
		{
			Date date=new Date();
			SimpleDateFormat simpleDateFormat=new SimpleDateFormat("dd/MM/yyyy");
			return simpleDateFormat.format(date);
		}
		
		
		
		//Get Session
		//Decide what sort of session i need.. open or current session
		private Session getSession() 
		{
			Session session = sessionFactory.getCurrentSession();
			return session;
		}
		
		
		
		
		
		/*public void saveRecord(Customer customer) 
		{	
			Date date=new Date();
			SimpleDateFormat simpleDateFormat=new SimpleDateFormat("dd/MM/yyyy");
			customer.setCreate_date(simpleDateFormat.format(date));
			//customer.setCreated_by();
			sessionFactory.getCurrentSession().save(customer);	
		}	
		 
		
		
		public void deleteRecordByCustomerCode(String customer_code) 
		{
		
			Customer customer=(Customer)sessionFactory.getCurrentSession().load(Customer.class,customer_code);
		
			if(customer!=null)
			{
				this.sessionFactory.getCurrentSession().delete(customer);
			}	
		
		}
		 
		public Customer getRecordByCustomerId(String customer_code) 
		{
		
			Customer customer1=(Customer)sessionFactory.getCurrentSession().get(Customer.class, customer_code);	
			return customer1 ;
		
		}
		//@SuppressWarnings("unchecked")
		 
		public List<Customer> show() 
		{		
		
			@SuppressWarnings("unchecked")
			List<Customer> list1=sessionFactory.getCurrentSession().createQuery("from Customer").list();
			return list1;
		
		}
		 
		public Customer update2(Customer customer) 
		{
		
			sessionFactory.getCurrentSession().update(customer);
			return customer;
		
		}
		 
		public Customer update1(String customer_code) 
		{
			Customer customer3=(Customer)sessionFactory.getCurrentSession().get(Customer.class, customer_code);
			return customer3;
		}
		
	//================================================================	
		 
		public List<Customer> viewByName(String customer_name) 
		{
			Query query=sessionFactory.getCurrentSession().createQuery("from Customer where customer_name=:name");
			query.setParameter("name", customer_name);
			List<Customer> customer=query.list();
			return customer;
		}*/

	}