package com.nucleus.brd3.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.brd3.model.persistence.entity.Authority;
import com.nucleus.brd3.model.persistence.entity.User;
import com.nucleus.brd3.service.AuthorityService;



@Controller
public class AdminController 
{

	
	//	final static Logger LOGGER=Logger.getLogger(LoginController.class);
	
	
	@Autowired
	AuthorityService authorityService;	

	
	/*@RequestMapping("/adduser")
	public ModelAndView requestHandler1(User user, Role role)
	{
		return new ModelAndView("addNewUser");
	}*/
	
	@RequestMapping("/addNewUser")
	public ModelAndView addNewUser(User user, Authority role)
	{
		return new ModelAndView("addNewUser");
	}
	
	
	
	
	
	@RequestMapping("/back")
	public ModelAndView requestHandler2(User user, Authority role)
	{
		return new ModelAndView("addNewUser");
	}
	
	
	
	
	
	
	/*@RequestMapping("/submitdetails")
	public ModelAndView save(User user)
	{   
	
		roleService.saveRecord(user);
		return new ModelAndView("newSignin", "success", " New user Registered");
	
	}*/
	
	
	
	

	
	//Add New User-------------------------------------------------------------------------------------
	@RequestMapping("/addedUser")
	public ModelAndView addedUser(User user)
	{   
	
		authorityService.addUser(user);
	
		return new ModelAndView("newSignin", "success", " New user Registered");
	    //To Page "NewSign-In"
	}
	
	
	
	
	
	
	/*@RequestMapping("/viewuser")
	public ModelAndView requestHandler3()
	{
		List<User> list=roleService.viewUserName();
		
		return new ModelAndView("ViewAllUserRecords","c",list);
	}*/

	
	
	@RequestMapping("/viewUser")
	public ModelAndView viewUsers()
	{
		List<User> theUsers = authorityService.viewUsers();
		
		return new ModelAndView("ViewUserRecords","Users",theUsers);
	
	}
	
}