package com.nucleus.brd3.model.persistence.dao;

//import java.util.ArrayList;
import java.util.List;

//import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
//import org.springframework.transaction.annotation.Transactional;

//import com.nucleus.brd3.model.persistence.entity.Customer;
import com.nucleus.brd3.model.persistence.entity.User;

@Repository
public class AuthorityDaoImpl implements AuthorityDao
{
	
	
	@Autowired
	SessionFactory sessionFactory;
	
	
	@Autowired
	BCryptPasswordEncoder bCryptPasswordEncoder;


	

//View Users---------------------------------------------------------------------------------------------------------
	
	
	
	
	
	@SuppressWarnings("unchecked")
	public List<User> viewUsers() 
	{
	
		Session session = sessionFactory.getCurrentSession();
		
		List<User> theUsers = session.createQuery("from Customer").list();
		
		return theUsers;
	}


	
	
	
//Add Users-------------------------------------------------------------------------------------------------------------	
	
	
	
	
	
	public void addUser(User user) 
	{
		Session session = sessionFactory.getCurrentSession();
		
		user.setEnabled(1);
		
		user.setPassword(encodePassword(user.getPassword()));
		
		session.save(user);
		
	}


	
	
	
	
//B-crypt---------------------------------------------------------------------------------------------------------
	
	
	
	
	
	
	
	public String encodePassword(String password) 
	{	
		return bCryptPasswordEncoder.encode(password);
	}
	
	
	
	
	

//----------------------------------------------------------------------------------------------------------------------	
	 
	/*public void saveRecord(User user) 
	{
		
		
		user.setEnabled(1);
		String enocodedpassword=encodePwd(user.getPassword());
		user.setPassword(enocodedpassword);
		
		sessionFactory.getCurrentSession().saveOrUpdate(user);	
	}

	 
	
	public List<User> viewUserName() 
	{
		List<User> userName=new ArrayList<User>();
		Query query=sessionFactory.getCurrentSession().createQuery("from User");
		userName=query.list();
		return userName;
	}
	
	
	
	public String encodePwd(String pwd) 
	{
		return bCryptPasswordEncoder.encode(pwd);
		
	}*/


}
