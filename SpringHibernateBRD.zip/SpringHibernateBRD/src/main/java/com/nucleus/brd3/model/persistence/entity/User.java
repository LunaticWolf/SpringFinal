package com.nucleus.brd3.model.persistence.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;




@Entity
@Table(name="User_Brd3_18060169")
@SequenceGenerator(name="auserSequence", sequenceName="auserSequence", allocationSize=2)
public class User implements Serializable
{
	
	private static final long serialVersionUID = 1L;
	
	
	
//User table fields	
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="auserSequence")
	@Column(unique=true)
	private int userId;
	
	
	@Column(name="user_Name")
	private String userName;
	
	@Column(name="password")
	private String password;
	
	@Column(name= "enabled")
	private int enabled;
	
	
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="roleId")
	private Authority role;
	
	
	
	
//Constructors-------------------------------------------------------------------------------------	
	
	
	
	
	
	
	public User() {}
	
	
	
	public User(String userName, String password,int enabled) 
	{
		super();
		this.userName=userName;
		this.password=password;
		this.enabled=enabled;
	}
	
	
	
	
	
	
	
//Setters-------------------------------------------------------------------------------------------		


	public void setUserId(int userId) {
		this.userId = userId;
	}



	public void setUserName(String userName) {
		this.userName = userName;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}



	public void setRole(Authority role) {
		this.role = role;
	}

	
	
	
//Getters-------------------------------------------------------------------------------------------------------	


	public int getUserId() {
		return userId;
	}



	public String getUserName() {
		return userName;
	}



	public String getPassword() {
		return password;
	}



	public int getEnabled() {
		return enabled;
	}



	public Authority getRole() {
		return role;
	}

	
	
	
	
	
//To String ----------------------------------------------------------------------------------------------------
	
	
	@Override
	public String toString() 
	{
		return "User [userId=" + userId + ", userName=" + userName
				+ ", password=" + password + ", enabled=" + enabled + ", role="
				+ role + "]";
	}
	
}
