package com.nucleus.brd3.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.brd3.model.persistence.entity.Customer;
import com.nucleus.brd3.service.CustomerService;

@Controller
public class UserController 
{
	
//	final static Logger LOGGER=Logger.getLogger(LoginController.class);
	
	private static String targetUrl=null;
	
	
	
	@Autowired
	CustomerService customerService;
	
	

	
	
	
//Split View Content---------------------------------------------------------------------------	
	/*@RequestMapping("/index")
	public String requestHandler5()
	{
		return "split";
		targetUrl="split";
		return targetUrl;
	
	}*/
	
	
	@RequestMapping("/index")
	public String SplitView()
	{
		return "split";
	
	}
	
	
	
	
	
//Nav Bar---------------------------------------------------------------------------------------
	
	/*@RequestMapping("/menuindex")
	public String requestHandler99()
	{
		return "index1";
		targetUrl="index1";
		return targetUrl;
	}*/
	
	
	@RequestMapping("/menuindex")
	public String NavBar()
	{
		return "index1";
	}

	
	
	
	

	
	
	
//ADD	
//Add New Record ----------------------------------------------------------------------------------------	
	
	
	
	/*@RequestMapping("/insert")
	public ModelAndView insert(Customer customer)
	{  
		return new ModelAndView("addcustomer");
	
	}*/
	

	@RequestMapping("/addNewRecord")
	public ModelAndView addRecord(Customer customer)
	{  
		
		//Add Form Page...
		return new ModelAndView("NewRecord");
	
	}

	
	
	
//Save Added Record-------------------------------------------------------------------------------------------	
	
/*	@RequestMapping("/add1")
	public ModelAndView save(@Valid Customer customer , BindingResult result)
	{   
		if(result.hasErrors())
		{
			return new ModelAndView("addcustomer");
		}
		
		customerService.saveRecord(customer);
		
		return new ModelAndView("success");
	}*/
	
	
	@RequestMapping("/addRecord")
	public ModelAndView addRecord(@Valid Customer customer , BindingResult result)
	{   
		if(!(result.hasErrors()))
		{
			customerService.addRecord(customer);
			
			//Return Success Message
			return new ModelAndView("success");
			//To "Success" page
		}
		
		else
		{
			//Add error Message here....
			return new ModelAndView("NewRecord");
			
			//To "New Record" Page
		}	
	}
	
	
	
	
	
	
	
	
	

	
	
//View Records-------------------------------------------------------------------------------------------	
	
	
	
		/*@RequestMapping("/View")
		public ModelAndView handler6()
		{ 
			
			List<Customer> list=customerService.show();
			return new ModelAndView("ViewAll","c",list);
		}*/
	
	
		@RequestMapping("/viewRecords")
		public ModelAndView viewRecords()
		{ 
			List<Customer> theCustomers = customerService.getRecords();
			
			return new ModelAndView("ViewAll","theCustomers",theCustomers);
			
			//To "ViewAll" Page....
		}
		
		
		
//Checker--------------------------------------------------------------------------------------------
		
		
		
		/*@RequestMapping("/checker")
		public String requestHandler6()
		{
			return "checker";
			targetUrl="checker";
			return targetUrl;
			
		}*/		
	
		
	
		@RequestMapping("/checker")
		public String checker()
		{
			return "checker";
			
		}
		
		
		
		
		
		
		
		
		
		
		
	
	
//Single View--------------------------------------------------------------------------------------------------------	
	
	

	
	/*@RequestMapping("/singleview")
	public ModelAndView view1(Customer customer)
	{
		
		return new ModelAndView("View1");
	}*/
		

		/*@RequestMapping("/view2")
		public ModelAndView view(@RequestParam("customer_code") String customer_code)
		{
			Customer customer=customerService.getRecordByCustomerId(customer_code);
			
			
			if(customer==null)
			{
				return new ModelAndView("error");
			}
			else

			return new ModelAndView("Viewone","customer",customer);
		}*/
		
		
		
		
		@RequestMapping("/singleViewByCode")
		public ModelAndView viewByCode(Customer customer)
		{
			return new ModelAndView("View1");
			
			//To Page "View1"
		}
		
		
		@RequestMapping("/viewByCode")
		public ModelAndView viewRecordByCode(@RequestParam("customerCode") String customerCode)
		{
			Customer theCustomer = customerService.getRecordByCode(customerCode);
			
			
			if(theCustomer!=null)
			{
				return new ModelAndView("Viewone","theCustomer",theCustomer);
				//To "Viewone" Page
			}
			
			else
				return new ModelAndView("error");
	            //To "error" page
		}
	
	
	
	
	
	
	
	
	
	

//Single View ----------------------------------------------------------------------------------------------------	
	
	
	/*@RequestMapping(value="viewbyname")
	public String name()
	{
		return "viewByName";
		targetUrl="viewByName";
		return targetUrl;
	}
	
	
	
	@RequestMapping(value="viewName")
	public ModelAndView viewName(@RequestParam("name") String customer_name)
	{
		List<Customer> customer=customerService.viewByName(customer_name);
		return new ModelAndView("ViewCustomer","customer",customer);
		
	}*/
	
		
		@RequestMapping("/singleViewByName")
		public String viewByName()
		{
			return "viewByName";
			//Page "viewByName"
		}
		
		
		
		@RequestMapping("/viewByName")
		public ModelAndView viewRecordByName(@RequestParam("customerName") String customerName)
		{
			
			List<Customer> theCustomer = customerService.getRecordByName(customerName);
			
			return new ModelAndView("ViewCustomer","theCustomer",theCustomer);
			//To "ViewCustomer" Page
			
		}
	
	

	
	
	
	
	
	
	
	
//Update ----------------------------------------------------------------------------------------------------------
	
	
	/*@RequestMapping("/update")
	public ModelAndView updates(Customer customer)
	{
		
		return new ModelAndView("Update1");
	}
	
	
	@RequestMapping("/update2")
	public ModelAndView updates1(@RequestParam("customer_code") String customer_code)
	{
		
		Customer customer=customerService.update1(customer_code);
		if(customer==null)
		{
			return new ModelAndView("error");
		}
		else
			
		return new ModelAndView("Updateone","customer",customer);
	}
	
	
	
	@RequestMapping("/update123")
	public ModelAndView saveupdate(@Valid Customer customer, BindingResult result)
	{  
		if(result.hasErrors())
		{
			return new ModelAndView("Updateone");
		}
		customer.setModified_date(new SimpleDateFormat("dd/MM/YYYY").format(new Date()));
		customerService.update2(customer);
		return new ModelAndView("success");	
	}*/

	
		
		
		@RequestMapping("/updateId")
		public ModelAndView updateId(Customer customer)
		{	
			return new ModelAndView("Update1");
			//To "Update1" page
		}
		
		
		@RequestMapping("/updateForm")
		public ModelAndView updateForm(@RequestParam("customerCode") String customerCode)
		{
			
			
			Customer theCustomer = customerService.getRecordByCode(customerCode);
			//Customer theCustomer = customerService.getRecordToUpdate(customerCode);
	
			if(theCustomer!=null)
			{
		
				return new ModelAndView("Updateone","theCustomer", theCustomer);
				//Page = " Updateone" (Form)
				
			}
			else
			{
				//Add Message here
				return new ModelAndView("error");
				//To Error page
			}
		
		}
		
		
		
		@RequestMapping("/updateRecord")
		public ModelAndView updateRecord(@Valid Customer customer, BindingResult result)
		{  
			if(result.hasErrors())
			{
				customerService.updateRecord(customer);
				
				return new ModelAndView("success");
				//To "Success" Page
		
			}
			else
			{
				return new ModelAndView("Updateone");
			}
		}
	
	
	

	
	
	
//Delete Existing Record---------------------------------------------------------------------------	

		
		
		
		/*@RequestMapping("/delete")
		public ModelAndView delete(Customer customer)
		{
			
			return new ModelAndView("deleteCustomer");
		}
		@RequestMapping("/delete2")
		public ModelAndView deleterecord(@RequestParam("customer_code") String customer_code)
		{
			customerService.deleteRecordByCustomerCode(customer_code);
			return new ModelAndView("success");
		}*/
		
	
		
		@RequestMapping("/deleteId")
		public ModelAndView deleteId(Customer customer)
		{
			return new ModelAndView("deleteRecord");
			//To "deleteCustomer" Page
		}
		
		
		
		@RequestMapping("/deleteRecord")
		public ModelAndView deleteRecord(@RequestParam("customerCode") String customerCode)
		{
			customerService.deleteRecord(customerCode);
			
			return new ModelAndView("success");
			//To "Success" page
		}
	
}