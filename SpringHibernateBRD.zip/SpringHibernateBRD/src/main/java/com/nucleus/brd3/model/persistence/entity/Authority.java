package com.nucleus.brd3.model.persistence.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.SequenceGenerator;
import javax.persistence.Table;




@Entity
@Table(name="Profile_Brd3_18060169")
@SequenceGenerator(name="aRoleSequence" , sequenceName=" aRoleSequence" , allocationSize=2)
public class Authority implements Serializable 
{
	
	private static final long serialVersionUID = 1L;
	
	
	
	
//Role Table Fields-----------------------------------------------------------------------------------------------	
	
	
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE , generator="aRoleSequence")
	@Column(unique=true)
	private int roleId;
	
	
	@Column(name="role_name")
	private String roleName;
	
	
	
	
//Constructor----------------------------------------------------------------------------------------------------

	
	public Authority() {}
	
	
	
	public Authority(String role)
	{
		if(role.equalsIgnoreCase("admin"))
			{ 
				roleName="ROLE_ADMIN";
			}
		
		else if(role.equalsIgnoreCase("user"))
			{
				roleName="ROLE_USER";
			}
		
		else
			roleName="NULL";
	}
	
	
	
	
	
	
//Defaults------------------------------------------------------------------------------------------------------------------------------	
//Getters---------------------------------------------------------------------------------------------------	
	
	
	
	
	public int getRoleId() 
	{
		return roleId;
	}
	
	
	
	public String getRoleName() 
	{
		return roleName;
	}
	

	
	
	
//Setters--------------------------------------------------------------------------------------------------------

	
	
	
	public void setRoleId(int roleId) 
	{
		this.roleId = roleId;
	}
	
	
	
	public void setRoleName(String roleName) 
	{
		this.roleName = roleName;
	}
	
	

	
	
	
	
//To string------------------------------------------------------------------------------------------------------
	
	
	
	
	@Override
	public String toString() 
	{
		return "Role [roleId=" + roleId + ", roleName=" + roleName + "]";
	}

}
