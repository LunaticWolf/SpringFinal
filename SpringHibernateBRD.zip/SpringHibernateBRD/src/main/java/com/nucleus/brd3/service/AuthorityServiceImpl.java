package com.nucleus.brd3.service;


import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.brd3.controller.LoginController;
import com.nucleus.brd3.model.persistence.dao.AuthorityDao;
import com.nucleus.brd3.model.persistence.entity.User;


@Service
@Transactional
public class AuthorityServiceImpl implements AuthorityService
{
	
	final static Logger LOGGER=Logger.getLogger(LoginController.class);
	

	@Autowired
	AuthorityDao authorityDao;


	public String encodePwd(String pwd) 
	{
		return authorityDao.encodePwd(pwd);
	}


	public List<User> viewUsers() 
	{
		return authorityDao.viewUsers();
	}


	public void addUser(User user) 
	{
		authorityDao.addUser(user);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
/*	@Transactional
	public void saveRecord(User user) 
	{
		roleDao.saveRecord(user);
		
	}

	@Transactional
	public List<User> viewUserName() 
	{
		return roleDao.viewUserName() ;
	}
	
	@Transactional
	public String encodePwd(String pwd) 
	{
	
		return roleDao.encodePwd(pwd);
		
	}
	*/

	

}

