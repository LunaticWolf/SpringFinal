package com.nucleus.brd3.model.persistence.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;

@Entity
@Table(name="Customer_BRD3_18060169")
public class Customer implements Serializable 
{
	
	private static final long serialVersionUID = 1L;
	
	
//Customer Table Field---------------------------------------------------------------------------------------------	
	
//Generated Explicitly
//Server Side Validation	
	
	@Id
	@NotNull
	@Column(unique=true, name="customer_code")
	private String customerCode;
	
	
	@NotNull
	@Length(min=3,max=20)
	@Column(name="customer_name")
	private String customerName;
	
	
	@NotNull
	@Length(min=3,max=20)
	@Column(name="customer_address")
	private String customerAddress;
	
	
	@NotNull
	@Min(value=6)
	@Column(name="customer_pincode")
	private int customerPinCode;
	
	
	@NotNull
	@Email()
	@Column(name="customer_email")
	private String emailAddress;
	
	
	@NotNull
	@Length(min=10,max=10)
	@Column(name="customer_contact_number")
	private String contactNumber;

	
	
	
	
	
//Generated Implicitly	
	
	@Column(name="customer_created_date")
	private String createdDate;
	
	
	@Column(name="customer_created_by")
	private String createdBy;
	
	
	@Column(name="customer_modified_date")
	private String modifiedDate;


	
	
	
	
	
	
//Getters----------------------------------------------------------------------------------
	
	
	
	
	public String getCustomerCode() 
	{
		return customerCode;
	}

	
	

	public String getCustomerName() 
	{
		return customerName;
	}


	
	
	public String getCustomerAddress() 
	{
		return customerAddress;
	}

	
	

	public int getCustomerPinCode() 
	{
		return customerPinCode;
	}


	
	
	public String getEmailAddress() 
	{
		return emailAddress;
	}


	
	
	public String getContactNumber() 
	{
		return contactNumber;
	}

	
	

	public String getCreatedDate() 
	{
		return createdDate;
	}

	
	

	public String getCreatedBy() 
	{
		return createdBy;
	}

	

	public String getModifiedDate() 
	{
		return modifiedDate;
	}

	
	
	
	
	
	
//Setters---------------------------------------------------------------------------------------	

	
	
	
	
	public void setCustomerCode(String customerCode) 
	{
		this.customerCode = customerCode;
	}




	public void setCustomerName(String customerName) 
	{
		this.customerName = customerName;
	}




	public void setCustomerAddress(String customerAddress) 
	{
		this.customerAddress = customerAddress;
	}




	public void setCustomerPinCode(int customerPinCode) 
	{
		this.customerPinCode = customerPinCode;
	}




	public void setEmailAddress(String emailAddress) 
	{
		this.emailAddress = emailAddress;
	}




	public void setContactNumber(String contactNumber) 
	{
		this.contactNumber = contactNumber;
	}




	public void setCreatedDate(String createdDate) 
	{
		this.createdDate = createdDate;
	}




	public void setCreatedBy(String createdBy) 
	{
		this.createdBy = createdBy;
	}




	public void setModifiedDate(String modifiedDate) 
	{
		this.modifiedDate = modifiedDate;
	}


	


	
	
	
//To String--------------------------------------------------------------------------------------
	
	
	@Override
	public String toString() 
	{
		return "Customer [customer_code=" + customer_code + ", customer_name=" + customer_name + ", customer_address="
				+ customer_address + ", customer_pinCode=" + customer_pinCode + ", email_address=" + email_address
				+ ", contact_number=" + contact_number + ", created_date=" + created_date + ", created_by=" + created_by
				+ ", modified_date=" + modified_date + "]";
	}

	
	
	
	
	
}
