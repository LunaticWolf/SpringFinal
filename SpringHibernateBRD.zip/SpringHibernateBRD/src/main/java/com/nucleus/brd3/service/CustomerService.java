package com.nucleus.brd3.service;

import java.util.List;

import com.nucleus.brd3.model.persistence.entity.Customer;

public interface CustomerService 
{
	
	
	//Add Record	
		public void addRecord(Customer customer);
		
		
	//View Records
		public List<Customer> getRecords();
		
		
	//Single-View By Code
		public Customer getRecordByCode(String customerCode);
		
		
	//Single-View By Name
		public List<Customer> getRecordByName(String customerName);
		
		
	//Update Record
		public Customer getRecordToUpdate(String customerCode);
		public void updateRecord(Customer customer);
		
		
	//Delete Record
		public void deleteRecord(String customerCode);
		
	
		
		
	//public void saveRecord(Customer customer);	
	//public Customer getRecordByCustomerId(String customer_code);
	//public void deleteRecordByCustomerCode(String customer_code);
	//public Customer update2(Customer customer);
	//public Customer update1(String customerid);
	//public List<Customer> show() ;
	//public List<Customer> viewByName(String customer_name);

	

}
