package com.nucleus.brd3.utility;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

/********************************************************           
 * PasswordEncoder --Encoding password			        *   
 *                                                      *   
 * Author:  SHIAVM SHRIVASTAV                           *   
 *                                                      *   
 * Purpose: To encrypt password				            *   
 *                                                      *   
 * Usage:                                               *   
 *      encrypts password by Bcrypt algorithm	        *   
 ********************************************************/ 
public class PasswordEncoder {
	
		public static String encodePwd(String pwd)
		{
			BCryptPasswordEncoder bCryptPasswordEncoder=new BCryptPasswordEncoder();//encoding
			
			return bCryptPasswordEncoder.encode(pwd);
		}
	}

