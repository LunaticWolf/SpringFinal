package com.nucleus.brd3.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.brd3.controller.LoginController;
import com.nucleus.brd3.model.persistence.dao.CustomerDao;
import com.nucleus.brd3.model.persistence.entity.Customer;

/********************************************************           
 * CustomerDaoImpl --Implements the interface           *   
 *                                                      *   
 * Author:  SHIAVM SHRIVASTAV                           *   
 *                                                      *   
 * Purpose: To Perform crud operation                   *   
 *                                                      *   
 * Usage:                                               *   
 *      Crud operations are performed through this      *   
 ********************************************************/ 

@Service
public class CustomerServiceImpl implements CustomerService
{
	final static Logger LOGGER=Logger.getLogger(LoginController.class);
	
	
	@Autowired
	CustomerDao customerDao;//injecting customer dao bean

	@Transactional//defining transactional
	public void saveRecord(Customer customer) //service to provide customer insertion
	{
		customerDao.saveRecord(customer);
		
	}
	@Transactional
	public Customer getRecordByCustomerId(String customer_code) //service to provide customer extraction by code
	{
		
		return customerDao.getRecordByCustomerId(customer_code);
	}
	@Transactional
	public void deleteRecordByCustomerCode(String customer_code) {//service to provide customer deletion
		customerDao.deleteRecordByCustomerCode(customer_code);
		
	}
	@Transactional
	public Customer update2(Customer customer) {//service to provide customer updation
		
		customer.setModified_date(new SimpleDateFormat("dd/MM/YYYY").format(new Date()));
		return customerDao.update2(customer);
	}
	@Transactional
	public Customer update1(String customerid) {//service to provide customer updation by code
		
		return customerDao.update1(customerid);
	}
	@Transactional
	public List<Customer> show() {  //service to provide customers by name
		// TODO Auto-generated method stub
		return customerDao.show();
	}
	public List<Customer> viewByName(String customer_name) {
		return customerDao.viewByName(customer_name);
	}

}
