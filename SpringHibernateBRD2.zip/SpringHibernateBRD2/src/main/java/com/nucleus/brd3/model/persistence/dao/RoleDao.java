package com.nucleus.brd3.model.persistence.dao;

import java.util.List;
import com.nucleus.brd3.model.persistence.entity.User;

/*
/*******************************************************           
* RoleDao --Interface For Dao Operations         	   *   
*                                                      *   
* Author:  SHIAVM SHRIVASTAV                           *   
*                                                      *   
* Purpose: To declare All the methods in Dao           *   
*                                                      *   
* Usage:                                               *   
*      Declares and makes outline for DaoImp	       *   
********************************************************/  

//interface having methods for operations on users
public interface RoleDao {

	public void saveRecord(User user);
	public List<User> viewUserName(); 
	public String encodePwd(String pwd);
}
