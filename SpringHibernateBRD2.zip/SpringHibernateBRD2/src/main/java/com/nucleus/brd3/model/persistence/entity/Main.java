package com.nucleus.brd3.model.persistence.entity;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;


public class Main {

	@Autowired
	static
    SessionFactory sessionFactory;
	
	public static void main(String[] args) {
		
		Role role=new Role("admin");
		User user= new User("root","toor",1);
		user.setRole(role);
		sessionFactory.getCurrentSession().save(user);
		sessionFactory.getCurrentSession().save(role);
	
		sessionFactory.close();
		
}
}
