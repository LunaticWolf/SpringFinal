package com.nucleus.brd3.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.brd3.model.persistence.entity.Role;
import com.nucleus.brd3.model.persistence.entity.User;
import com.nucleus.brd3.service.RoleService;
/********************************************************           
 * Handling --Dispatching Login page Requests.   		*   
 *                                                      *   
 * Author:  SHIVAM SHRIVASTAV                           *   
 *                                                      *   
 * Purpose: ADMIN CONTROL	                            *   
 *                                                      *   
 * Usage:                                               *   
 *      ADMIN LOGIN AND ADMIN ACCSESS					*   
 ********************************************************/



@Controller
public class NewUserController 
{
	final static Logger LOGGER=Logger.getLogger(NewUserController.class);
	
	
	@Autowired
	RoleService roleService;
	
	//*************ADD NEW USER PAGE***********//
	@RequestMapping("/adduser")
	public ModelAndView requestHandler1(User user, Role role)
	{
		return new ModelAndView("addNewUser");
	}
	
	
	/*@RequestMapping("/back")
	public ModelAndView requestHandler2(User user, Role role)
	{
		return new ModelAndView("addNewUser");
	}*/
	
	//*************ADD NEW USER PAGE ACTION***********//
	@RequestMapping("/submitdetails")
	public ModelAndView save(User user)
	{   
		roleService.saveRecord(user);
		return new ModelAndView("newSignin", "success", " New user Registered");
	}
	
	//*************VIEW ALL USERS***********//
	@RequestMapping("/viewuser")
	public ModelAndView requestHandler3()
	{
		List<User> list=roleService.viewUserName();
		return new ModelAndView("ViewAllUserRecords","c",list);
	}
}