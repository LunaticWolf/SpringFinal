package com.nucleus.brd3.service;


import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.brd3.controller.LoginController;
import com.nucleus.brd3.model.persistence.dao.RoleDao;
import com.nucleus.brd3.model.persistence.entity.User;

/********************************************************           
 * UserServiceImpl --Implements the interface           *   
 *                                                      *   
 * Author:  SHIAVM SHRIVASTAV                           *   
 *                                                      *   
 * Purpose: To Perform crud operation                   *   
 *                                                      *   
 * Usage:                                               *   
 *      Crud operations are performed through this      *   
 ********************************************************/  


@Service
public class RoleServiceImpl implements RoleService
{
	
	final static Logger LOGGER=Logger.getLogger(LoginController.class);
	

	@Autowired
	RoleDao roleDao;//injecting RoleDao
	
	@Transactional
	public void saveRecord(User user) //providing service to user add
	{
		roleDao.saveRecord(user);
		
	}

	@Transactional
	public List<User> viewUserName() //to view all users
	{
		return roleDao.viewUserName() ;
	}

	@Transactional
	public String encodePwd(String pwd) {//encrypting password 
	
		return roleDao.encodePwd(pwd);
		
	}

}

