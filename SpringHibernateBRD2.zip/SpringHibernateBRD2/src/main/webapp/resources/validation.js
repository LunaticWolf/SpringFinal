function validation()
{
var pinCode =document.InsertCustomer.customerPinCode.value;
var address=document.InsertCustomer.customerAddress.value;
var eMail = document.InsertCustomer.customerEmail.value;
var contact=document.InsertCustomer.contactNumber.value;
var name=document.InsertCustomer.customerName.value;
var letters = /^[A-Za-z]+$/;
var Email = /^([a-z A-Z 0-9 _\.\-])+\@(([a-z A-Z 0-9\-])+\.)+([a-z A-z 0-9]{3,3})+$/;
var numbers = /^[0-9]+$/;
var flag=0;


if(pinCode .match(numbers)){}
else{
	alert('pincode must be 6-digit number');
	flag++;
}
if(pinCode.length==6){}
else{
	alert('pincode must be 6-digit number');
	flag++;
}
if(eMail.match(Email)){}
else {
	alert('Enter valid email Address');
	flag++;
}
if (name==null || name=="")
{
alert("Please enter Customer Name");
      flag++;
}
if(name.match(letters)){}
else
{
alert('Username must have alphabet characters only');
flag++;
}
if((contact.match(numbers))){}
else{
alert('Enter valid contact number');
flag++;
}
if(contact.length==0)
{
alert('Field cannot be empty');
}

if(address.length==0)
{
alert('Address field cannot be empty');
return false;
}


if(contact.length!=10)
{
alert('Contact Number should be a 10 digit number');
return false;
}

if(flag)
{
alert('Please Enter the Right Details for login');

return false;
}
else return true;
}