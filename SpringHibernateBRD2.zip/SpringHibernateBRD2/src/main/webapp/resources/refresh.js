window.history.forward();
    function noBack() { window.history.forward(); }
    
    function loadDoc() {
 	   var xhttp = new XMLHttpRequest();
 	   xhttp.onreadystatechange = function() {
 	    if (this.readyState == 4 && this.status == 200) {
 	     document.getElementById("demo").innerHTML = this.responseText;
 	    }
 	  };
 	  xhttp.open("GET", "View", true);
 	  xhttp.send();
 	 }
 	 window.setInterval(function(){loadDoc()},5000);