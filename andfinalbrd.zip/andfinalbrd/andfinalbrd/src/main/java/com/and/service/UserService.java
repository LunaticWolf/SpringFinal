package com.and.service;
/********************************************************           
 * UserService --Interface For Dao Operations           *   
 *                                                      *   
 * Author:  ANAND KUMAR SINGH                           *   
 *                                                      *   
 * Purpose: To declare All the methods in Dao           *   
 *                                                      *   
 * Usage:                                               *   
 *      Declares and makes outline for DaoImp	        *   
 ********************************************************/
import java.util.List;

import com.and.model.User;

//interface for user services
public interface UserService {

	public User adduser(User user);
	public void deleteUser(int id);
	public List<User> viewAllUser();
	/*public void logout();*/
}

