package com.and.service;
/********************************************************           
 * UserServiceImpl --Implements the interface           *   
 *                                                      *   
 * Author:  ANAND KUMAR SINGH                           *   
 *                                                      *   
 * Purpose: To Perform crud operation                   *   
 *                                                      *   
 * Usage:                                               *   
 *      Crud operations are performed through this      *   
 ********************************************************/  
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.and.dao.UserDao;
import com.and.model.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userDao; //injecting userDao
	final static Logger log = Logger.getLogger(UserServiceImpl.class.getName());
	@Transactional
	public User adduser(User user) { //providing service to user add
		EncodingPassword encode = new EncodingPassword(); //encrypting password first
		log.info("In service layer");
	    log.info("Encrypting Password");
	    log.info("calling dao to add User/admin");
		encode.encryptPass(user);
		userDao.addUser(user);
		return user;
	}

	@Transactional
	public void deleteUser(int id) { //delete user
		log.info("In service layer");
	    log.info("Calling Delete User dao");
		userDao.deleteUser(id);

	}

	@Transactional
	public List<User> viewAllUser() {//to view all users
		log.info("In service layer");
	    log.info("Calling View All user dao");
		return userDao.getAllUser();
	}

	

}
