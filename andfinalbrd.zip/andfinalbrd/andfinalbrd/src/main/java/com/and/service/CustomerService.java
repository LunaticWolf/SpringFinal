package com.and.service;
/********************************************************           
 * CustomerService --Interface For Dao Operations           *   
 *                                                      *   
 * Author:  ANAND KUMAR SINGH                           *   
 *                                                      *   
 * Purpose: To declare All the methods in Dao           *   
 *                                                      *   
 * Usage:                                               *   
 *      Declares and makes outline for DaoImp	        *   
 ********************************************************/
import java.util.List;

import com.and.model.Customer;
//interface for customer service
public interface CustomerService {

	public Customer addcustomer(Customer customer);
	public void deleteCustomer(int customerCode);
	public Customer viewCustomer(int customerCode);
	public List<Customer> viewCustomersByName(String customerName);
	public List<Customer> viewAll();
	public Customer updateCustomer(Customer customer);

}
