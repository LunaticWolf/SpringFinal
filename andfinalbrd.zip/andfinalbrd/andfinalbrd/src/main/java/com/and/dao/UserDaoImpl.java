package com.and.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.and.model.User;
/********************************************************           
 * CustomerDaoImpl --Implements the interface           *   
 *                                                      *   
 * Author:  ANAND KUMAR SINGH                           *   
 *                                                      *   
 * Purpose: To Perform crud operation                   *   
 *                                                      *   
 * Usage:                                               *   
 *      Crud operations are performed through this      *   
 ********************************************************/  
@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	SessionFactory factory; //loading session factory
	final static Logger log = Logger.getLogger(UserDaoImpl.class.getName());
	public User addUser(User user) {
		try{
			log.debug("adding user");
			factory.getCurrentSession().save(user); //adding new user
		}catch (HibernateException e) {
			log.error("could not add" + e.getMessage());
		}catch (Exception e) {
			log.error("could not add" + e.getMessage());
		}
		
		return user;
	}
 
	public void deleteUser(int id) { // deleting user
		User user = new User();
		user.setId(id);
		try{
			log.debug("in Dao for deleting user");
		factory.getCurrentSession().delete(user);
		}
		catch(HibernateException e){
			log.error("could not delte" + e.getMessage());
		}
		catch(Exception e){
			log.error("could not delte" + e.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	public List<User> getAllUser() { //getting list of all users
		List<User> list=new ArrayList<User>();
		try{
			log.debug("getting list of user");
		list= factory.getCurrentSession().createCriteria(User.class).list();
		}catch (HibernateException e) {
			log.error("could not find" + e.getMessage());
		}catch(Exception e){
			log.error("could not find" + e.getMessage());
		}
		return list;
	}

}
