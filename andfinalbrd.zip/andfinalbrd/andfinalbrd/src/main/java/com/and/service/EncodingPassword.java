package com.and.service;

import java.util.logging.Logger;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.and.model.User;

public class EncodingPassword {

	static Logger log = Logger.getLogger(EncodingPassword.class.getName());
	
	BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder(); //BCryptPasswordEncoder instantiate
	
	public void encryptPass(User user)
	{
		String pass = passwordEncoder.encode(user.getPassword()); //encrypting passworrd
		user.setPassword(pass);
	}
}

