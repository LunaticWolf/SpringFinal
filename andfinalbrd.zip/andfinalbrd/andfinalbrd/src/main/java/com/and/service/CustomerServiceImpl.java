package com.and.service;
/********************************************************           
 * CustomerDaoImpl --Implements the interface           *   
 *                                                      *   
 * Author:  ANAND KUMAR SINGH                           *   
 *                                                      *   
 * Purpose: To Perform crud operation                   *   
 *                                                      *   
 * Usage:                                               *   
 *      Crud operations are performed through this      *   
 ********************************************************/  

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.and.dao.CustomerDao;
import com.and.model.Customer;

@Service 
public class CustomerServiceImpl implements CustomerService {
	final static Logger log = Logger.getLogger(CustomerServiceImpl.class.getName());
	@Autowired
	CustomerDao customerDao; //injecting customer dao bean

	@Transactional //defining transactional
	public Customer addcustomer(Customer customer) { //service to provide customer insertion
    log.info("In service layer");
    log.info("Calling add Customer dao");
		customerDao.addCustomer(customer);
		return customer;
	}

	@Transactional
	public void deleteCustomer(int customerCode) {//service to provide customer deletion
		log.info("In service layer");
	    log.info("Calling Delete customer dao");
		customerDao.deleteCustomer(customerCode);

	}

	@Transactional
	public Customer viewCustomer(int customerCode) {//service to provide customer extraction by code
		log.info("In service layer");
	    log.info("Calling get Customer by code dao");

		return customerDao.viewCustomerByCode(customerCode);
	}

	@Transactional
	public List<Customer> viewAll() { //service to provide customer extraction list
		log.info("In service layer");
	    log.info("Calling get all customer  dao");
		return customerDao.getAllCustomers();
	}

	@Transactional
	public Customer updateCustomer(Customer customer) {//service to provide customer updation
		log.info("In service layer");
	    log.info("Calling update Customer by code dao");
		return customerDao.updateCustomer(customer);
	}
	
	

	public List<Customer> viewCustomersByName(String customerName) { //service to provide customers by name
		log.info("In service layer");
	    log.info("Calling get all Customer by name dao");
		return customerDao.getAllCustomersByName(customerName);
	}

}
