package com.and.dao;
/********************************************************           
 * CustomerDao --Interface For Dao Operations           *   
 *                                                      *   
 * Author:  ANAND KUMAR SINGH                           *   
 *                                                      *   
 * Purpose: To declare All the methods in Dao           *   
 *                                                      *   
 * Usage:                                               *   
 *      Declares and makes outline for DaoImp	        *   
 ********************************************************/  
import java.util.List;

import com.and.model.Customer;
//interface for Customer Insertion
public interface CustomerDao {
	
	public Customer addCustomer(Customer customer);
	public void deleteCustomer(int customerCode);
	public Customer viewCustomerByCode(int customerCode);
	public List<Customer> getAllCustomers();
	public Customer updateCustomer(Customer customer);
	public List<Customer> getAllCustomersByName(String customerName);
	

}
