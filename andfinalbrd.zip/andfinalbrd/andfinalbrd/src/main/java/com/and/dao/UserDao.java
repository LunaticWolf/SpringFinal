package com.and.dao;

/*
 /********************************************************           
 * CustomerDao --Interface For Dao Operations           *   
 *                                                      *   
 * Author:  ANAND KUMAR SINGH                           *   
 *                                                      *   
 * Purpose: To declare All the methods in Dao           *   
 *                                                      *   
 * Usage:                                               *   
 *      Declares and makes outline for DaoImp	        *   
 ********************************************************/  

import java.util.List;

import com.and.model.User;

//interface having methods for operations on users
public interface UserDao {

	public User addUser(User user);
	public void deleteUser(int id);
	public List<User> getAllUser();
}
