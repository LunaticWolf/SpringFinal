package com.and.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.and.dao.CustomerDao;
import com.and.model.Customer;
/********************************************************           
 * ValidationService --VAlidations on values	        *   
 *                                                      *   
 * Author:  ANAND KUMAR SINGH                           *   
 *                                                      *   
 * Purpose: VAlidate user inputs			            *   
 *                                                      *   
 * Usage:                                               *   
 *     Validates all user inputs where required	        *   
 ********************************************************/
@Service
public class ValidationService {
	
	@Autowired
	CustomerDao customerDao;
	final static Logger log = Logger.getLogger(ValidationService.class.getName());

	public int validateCustomerCode(String customerCode) {
		log.info("validating Customer Code in Seervice");
		Customer cust=customerDao.viewCustomerByCode(Integer.parseInt(customerCode));
		if(customerCode.equals(null)){
			return 2;
		}
		if(cust!=null){
			return 0;
		}
		else{
		return 1;
		}
	}

	

}
