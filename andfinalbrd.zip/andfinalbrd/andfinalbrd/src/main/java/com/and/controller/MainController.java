package com.and.controller;

import java.security.Principal;
import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.and.model.Customer;
import com.and.model.User;
import com.and.service.CustomerService;
import com.and.service.UserService;
import com.and.service.ValidationService;
/********************************************************           
 * MainController --Handelling All the Request          *   
 *                                                      *   
 * Author:  ANAND KUMAR SINGH                           *   
 *                                                      *   
 * Purpose: To handle All the client requests           *   
 *                                                      *   
 * Usage:                                               *   
 *      dsipatches request to correct pages		        *   
 ********************************************************/  
@Controller
public class MainController {

	final static Logger log = Logger.getLogger(MainController.class.getName());

	@Autowired
	CustomerService customerService;
	@Autowired
	ValidationService validationService;
	@Autowired
	UserService userService;

	// ---LOADING HOME PAGE FOR CUSTOMER-----------------
	@RequestMapping(value = "/split")
	public String ShowCustomerHomePage() {

		return "Split";
	}

	// ------ ADDING NEW CUSTOMER----------------------------

	@RequestMapping("/addCustomer")	// load customer form
	public ModelAndView ShowCustomerForm(Customer customer) {
		log.info("Loading New Customer Form");
		return new ModelAndView("NewCustomerDetails");

	}

	@RequestMapping("/newCustomer")	// perform on customer form
	public ModelAndView addnewUser(@Valid @ModelAttribute(value="customer") Customer customer, BindingResult result,Principal p) {
		if(result.hasErrors()){
			return new ModelAndView("NewCustomerDetails");
		}
		
		log.info("Got Customer Details From UI");
		int cCode = customer.getCustomerCode();
		Customer cust = customerService.viewCustomer(cCode);
		if (cust != null) {
		log.info("Checking if Customer Exists");
			return new ModelAndView("NewCustomerDetails", "error",
					"Customer with this Code Already Exists"); // if customer already exists

		}
		customer.setCreatedBy(p.getName());
		    	log.info("Customer Added Successfully");
			customerService.addcustomer(customer);
			return new ModelAndView("NewCustomerDetails", "success",
					"Customer was Added SuccessFully"); // success
		

	}

	// -------TO DELETE CUSTOMER BY CODE--------------------
	@RequestMapping(value = "/deleteCustomer", method = RequestMethod.GET)
	// load page to get code
	public String getCodeToDelete() {
		log.info("Getting Form For Taking Customer Code To Delete");
		return "DeleteView";

	}

	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	// delete customer by code
	public ModelAndView delete(Model model,
			@RequestParam("customerCode") String customerCode) {

		int custCode = Integer.parseInt(customerCode);

		int flag = validationService.validateCustomerCode(customerCode);
		if (flag == 1) {
			log.info("Checking If Customer Exists");
			return new ModelAndView("DeleteView", "success",
					"Customer Does Not Exist");// customer code entered doesnt
												// exist
		} else if (flag == 2) {
			log.error("Custoemr Code was not inputted");
			return new ModelAndView("DeleteView", "success",
					"Enter Customer Code");
		} else {
			customerService.deleteCustomer(custCode);
			log.info("SuccessFully Deleted");
			return new ModelAndView("DeleteView", "success",
					"Customer was Deleted Successfully");// customer deleted
															// Successfully
		}

	}

	// ---------VIEW SINGLE CUSTOMER--------------------------------
	@RequestMapping(value = "/viewCustomer", method = RequestMethod.GET)
	// get code
	public String getCodeForSingleView() {
		log.info("Request For single View BY Code");
		return "singleviewload";

	}

	@RequestMapping(value = "/oneview", method = RequestMethod.POST)
	public ModelAndView oneview(Model model,
			@RequestParam("customerCode") String customerCode) {

		int flag = validationService.validateCustomerCode(customerCode);
		if (flag == 2) {
			log.error("Customer Code was Not Inserted");
			return new ModelAndView("singleviewload", "error",
					"You Must Enter Customer Code");
		}
		Customer customer = customerService.viewCustomer(Integer
				.parseInt(customerCode));
		model.addAttribute("customer", customer);
		if (customer != null) {
			log.info("Displaying Customer");
			return new ModelAndView("singleViewDisplay"); // display that
															// customer
		} else {
			log.fatal("Customer With that Code Not found");
			return new ModelAndView("singleviewload", "error",
					"No Customer Found With that code"); // if that customer
															// doesnt exist
		}
	}

	// -------------------VIEW ALL-----------------------
	@RequestMapping(value = "/viewall", method = RequestMethod.GET)
	public String viewAllUsers(Model model) {
		log.info("Request For View All Customers");
		List<Customer> customer = customerService.viewAll(); // load list of all
																// customers

		model.addAttribute("customer", customer);
		log.info("Displaying All Customers");
		return "viewAll"; // display that list

	}

	// -----------------VIEW BY NAME-----------------------------
	@RequestMapping(value = "/viewByName", method = RequestMethod.GET)
	public String viewByName() {
		log.info("Request for Displaying Customers By names");
		return "LoadCustomerName"; // load customer name

	}

	@RequestMapping(value = "/viewByInputName", method = RequestMethod.POST)
	public ModelAndView viewByInputName(Model model,
			@RequestParam("customerName") String customerName,
			@ModelAttribute Customer customer) {
		log.info("Loading list Of Customers By That name");
		List<Customer> cust = null;
		cust = customerService.viewCustomersByName(customerName);

		if (cust.size() > 0) {
			log.info("Displaying Customers");
			model.addAttribute("customer", cust);
			return new ModelAndView("viewByName");// display customers having
													// giving name
		} else {
			log.fatal("No Customers Found");
			return new ModelAndView("LoadCustomerName", "error",
					"No Customer Found With That name.");// if no customer with
															// that name exists
		}

	}

	// --------------------UPDATE CUSTOMER-----------------------
	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public String updateUser() {
		log.info("Request To Update customer");
		return "updateCustomerLoad"; // get code

	}

	@RequestMapping(value = "/updatevalue", method = RequestMethod.POST)
	public ModelAndView updateValue(Model model,
			@RequestParam("customerCode") String customerCode,
			@ModelAttribute Customer customer) {
		log.info("Getting Code from customer");
		customer = customerService.viewCustomer(Integer.parseInt(customerCode));

		int flag = validationService.validateCustomerCode(customerCode);
		if (flag == 2) {
			log.error("customer code was not inserted");
			return new ModelAndView("updateCustomerLoad", "error",
					"Enter Customer code");
		}
		model.addAttribute("customer", customer);
		if (customer != null) {
			log.info("Updating customer");
			return new ModelAndView("UpdateCustomer"); // update that customer
		} else {
			log.error("Customer was Not found");
			return new ModelAndView("updateCustomerLoad", "error",
					"No Customer Could Be Found By That Code"); // if customer
																// was not found
																// by that code
		}
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ModelAndView updated(@Valid @ModelAttribute(value="customer")Customer customer, BindingResult result) {
		if(result.hasErrors()){
			return new ModelAndView("UpdateCustomer");
		}
		customerService.updateCustomer(customer);
		log.info("Updated Successfully");
		return new ModelAndView("UpdateCustomer", "success",
				"Updation was successful"); // updation was successfull

	}

	// *************ADMIN AND USER*******************************//

	@RequestMapping(value = "/User")
	// load userpage
	public String loadUser() {

		return "SplitUser";

	}

	// ******************ADD USER********************************
	@RequestMapping("/adduser")
	public ModelAndView addUser(User user) {
		log.info("Request To Add NEw User");
		return new ModelAndView("NewUser"); // load user form
	}

	@RequestMapping("/newUser")
	public ModelAndView addnewUser(@Valid @ModelAttribute("user")User user) {
		log.info("Getting User Details");
		userService.adduser(user);
		log.info("User Added");
		return new ModelAndView("NewUser", "message", "User Was ADDED"); // user
																			// was
																			// added
																			// successfully

	}

	// ************************DELETE USER***************************

	@RequestMapping(value = "/deleteUser", method = RequestMethod.GET)
	public String deleteuser() {

		return "getUserCode";

	}

	@RequestMapping(value = "/deleteUser", method = RequestMethod.POST)
	public String deleteUser(Model model, @RequestParam("id") String id) {
		userService.deleteUser(Integer.parseInt(id));
		return "DeleteView";
	}

	// ***************VIEW ALL*********************************************
	@RequestMapping(value = "/viewallUser", method = RequestMethod.GET)
	public String viewAll(Model model) {
		log.info("request To View All");
		List<User> user = userService.viewAllUser();// load all users

		model.addAttribute("user", user);
		log.info("Displaying All");
		return "viewAllUser"; // display all users

	}

	@RequestMapping(value = "/viewallCustomer", method = RequestMethod.GET)
	public String viewallCustomer(Model model) {

		List<Customer> customer = customerService.viewAll(); // load all
		log.info("Admin Views All Customers"); // customers

		model.addAttribute("customer", customer);

		return "viewAll"; // display all customers

	}

}
