package com.nucleus.nsbt.brd4.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController 
{

//Home Screen after Login
	@GetMapping("/")
	public String showHome() 
	{		
		return "home";
	}
	
	
//User Screen
	@GetMapping("/userScreen")
	public String showUserScren() 
	{
		return "user-screen";
	}
	
	
	

//Admin Screen
	@GetMapping("/adminScreen")
	public String showSystems() 
	{
		return "admin-screen";
	}
	
}










